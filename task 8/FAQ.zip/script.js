// Search functionality
function searchFAQ() {
    const searchText = document.getElementById('search-bar').value.toLowerCase();
    const faqItems = document.querySelectorAll('.faq-item');
  
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question').textContent.toLowerCase();
        item.style.display = question.includes(searchText) ? 'block' : 'none';
    });
}

// Category filtering functionality
function filterCategory() {
    const selectedCategory = document.getElementById('category-filter').value;
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const category = item.getAttribute('data-category');
        item.style.display = selectedCategory === '' || category === selectedCategory ? 'block' : 'none';
    });
}

// Clear filters function
function clearFilters() {
    document.getElementById('search-bar').value = '';
    document.getElementById('category-filter').value = '';
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        item.style.display = 'block';
    });
}

// Expand/Collapse functionality with smooth animation
document.querySelectorAll('.faq-question').forEach(question => {
    question.addEventListener('click', () => {
        // Close any other open FAQ item
        const openQuestion = document.querySelector('.faq-question.open');
        if (openQuestion && openQuestion !== question) {
            openQuestion.classList.remove('open');
            openQuestion.nextElementSibling.style.maxHeight = null;
        }

        // Toggle the clicked question
        question.classList.toggle('open');
        const answer = question.nextElementSibling;
        if (question.classList.contains('open')) {
            answer.style.maxHeight = answer.scrollHeight + 'px'; // Expand
        } else {
            answer.style.maxHeight = null; // Collapse
        }
    });
});
